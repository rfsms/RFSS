/**
@file IdnSample.cpp
@brief *IDN example
@copyright (c) Rohde & Schwarz GmbH & Co. KG, Munich

This example illustrates how to find VISA resources, connect to a resource, and make a *IDN? query

*/

#include <iostream>
#include "VisaResourceManager.h"
#include "VisaSession.h"

int main()
{
  const std::string TestDevice = "TCPIP::127.0.0.1";

  std::cout << "VISA *IDN sample" << std::endl;

  try
  {
    VisaResourceManager rm;
	const bool findVXI11Devices = true;
	const bool findmDNSDevices = true;
    VisaResourceManager::devicelist_t availableRsrc = rm.findResources(findVXI11Devices, findmDNSDevices);

    std::cout << "Number Available VISA resources " << availableRsrc.size() << ": " << std::endl;
    for (auto& i : availableRsrc)
    {
      std::cout << " - " << i.VisaResourceString;
      std::cout << " intfType: " << i.intfType;
      std::cout << " intfNum: " << i.intfNum;
      std::cout << " rsrcClass: " << i.rsrcClass;
      std::cout << " expandedUnaliasedName: " << i.expandedUnaliasedName;
      if(!i.aliasIfExists.empty())
      {
        std::cout << " alias: " << i.aliasIfExists;
      }
    
      if(!i.hostname.empty())
      {
        std::cout << " hostname: " << i.hostname;
      }
      if(!i.description.empty())
      {
        std::cout << " description: \"" << i.description << "\"";
      }

      if(!i.manufacturer.empty())
      {
        std::cout << " identification: " << i.manufacturer << ','
          << i.model << ','
          << i.serialNumber << ','
          << i.version;
      }

      std::cout << '\n';
    }

    std::cout << "\n Trying to communicate with " << TestDevice << std::endl;

    VisaResourceManager::session_t mysession = rm.connect(TestDevice);

    mysession->write("*IDN?");
    std::cout << "status byte = " << mysession->readSTB() << std::endl;
    std::string readValue = mysession->read();
    std::cout << "*IDN? = " << readValue << std::endl;
    std::cout << "status byte = " << mysession->readSTB() << std::endl;

    rm.disconnect(mysession);
  }
  catch (VisaException ex)
  {
    std::cout << ex.what() << " -- " << VisaResourceManager::statusDescription(ex.getErrorCode()) << std::endl;
  }

  std::cout << "\nPress RETURN . . ." << std::endl;
  char c;
  std::cin.get(c);
  return EXIT_SUCCESS;
}
